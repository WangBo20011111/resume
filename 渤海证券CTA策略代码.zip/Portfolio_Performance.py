# -*- coding: utf-8 -*-
"""
Created on 2025/3/10 14:25
@author: Wang bo
"""
import pandas as pd
from matplotlib import pyplot as plt
import numpy as np
import seaborn as sns

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

file_path = '../Fundamental_Data/'
save_path = '../Result_Data/所有品种/'
factor_path = save_path + 'factor/'


#=====================================================================
#资产组合回撤
#=====================================================================


class PortfolioPerformance:
    def __init__(self, value_panel, strategy_df):
        self.KindsNumY = None
        self.value_panel = value_panel
        self.strategy_df = strategy_df
        self.signal = None
        self.value_df = None
        self.retD = None
        self.retY = None
        self.SharpeRatio = None
        self.MaxDrawdown = None
        self.metrics = None

    def setup(self):
        try:
            self.signal = self.value_panel[['date','kind','signal']]
        except:
            pass
        self.value_panel = self.value_panel.groupby(['date', 'kind'])['value'].sum().reset_index()
        self.value_df = pd.pivot(self.value_panel, index='date', columns='kind', values='value')
        self.ret()
        self.sharpe_ratio()
        self.max_drawdown()
        self.metrics = pd.concat([self.retY, self.SharpeRatio], axis=1)
        self.metrics = pd.concat([self.metrics, self.MaxDrawdown], axis=1)
        self.metrics.to_csv(save_path+'组合评价指标.csv', encoding='gbk')
        print('\n组合评价指标: \n',self.metrics.to_csv( sep='\t'))
        return self.retD

    def ret(self):
        profitD = self.value_df-self.value_df.shift(1)
        self.value_df.to_csv(save_path+'test.csv', encoding='gbk')
        #单品种的日度数据
        retD_single = profitD/1000000
        retD_single = pd.melt(
            retD_single.reset_index(),
            id_vars='date',
            value_vars=retD_single.columns,
            var_name='kind', value_name='ret'
        )
        try:
            merge = pd.merge(retD_single, self.signal, on=['date','kind'], how='left')
            drop_list = []
            valid_kinds_dict = {
                month:self.strategy_df.loc[self.strategy_df.index==month].dropna(axis=1).columns.tolist()
                for month in self.strategy_df.index.unique()
            }
            merge['YearMonth'] = merge['date'].dt.strftime('%Y%m')
            for index, row in merge.iterrows():
                month = row['date'].strftime('%Y%m')
                Kinds = valid_kinds_dict[month]
                if row['kind'] not in Kinds:
                    drop_list.append(index)
            merge = merge[~merge.index.isin(drop_list)]
            merge.to_csv(save_path+'单品种每日明细.csv', encoding='gbk')
        except:
            pass

        #组合日度收益
        profitD['Portfolio'] = profitD.sum(axis=1)
        def ret_daily(index, row):
            month = index.strftime('%Y%m')
            KindsNum = len(self.strategy_df.loc[self.strategy_df.index==month].dropna(axis=1).columns)
            #ret = row['Portfolio']/(KindsNum * 1000000)
            return KindsNum

        for index, row in profitD.iterrows():
            #result = ret_daily(index, row)
            profitD.loc[index, 'KindsNum'] = ret_daily(index, row)
            #profitD.loc[index, 'ret'] = result[1]

        self.retD = profitD[['Portfolio', 'KindsNum']]
        self.retD.columns = ['profit', 'KindsNum']
        self.retD.loc[:,'KindsNumY'] = self.retD.groupby(pd.Grouper(freq='YE'))['KindsNum'].transform('mean')
        self.retD.loc[:,'ret'] = self.retD['profit']/(self.retD['KindsNumY']*1000000)
        self.retD.to_csv(save_path+'组合每日明细.csv', encoding='gbk')

        #组合年度收益
        profitY = self.retD.groupby(pd.Grouper(freq='YE'))['profit'].sum()
        profitY.index = profitY.index.year
        self.KindsNumY = self.retD.groupby(pd.Grouper(freq='YE'))['KindsNum'].mean()
        self.KindsNumY.index = self.KindsNumY.index.year
        self.retY = profitY/(self.KindsNumY * 1000000)
        self.retY.name = 'ret'

    def sharpe_ratio(self):
        Vol = self.retD.dropna(subset=['ret']).groupby(pd.Grouper(freq='YE'))['ret'].std()*np.sqrt(252)
        Vol.index = Vol.index.year
        self.SharpeRatio = self.retY/Vol
        self.SharpeRatio.name = 'sharpe_ratio'

    def max_drawdown(self):
        portf_value = pd.DataFrame(self.retD['profit'])
        portf_value['Year'] = portf_value.index.year
        portf_value['cum'] = portf_value.groupby('Year')['profit'].cumsum()
        self.KindsNumY = pd.DataFrame(self.KindsNumY)
        self.KindsNumY.index.name = 'Year'
        portf_value = portf_value.join(self.KindsNumY, on='Year', how='left')
        portf_value['value'] = portf_value['KindsNum'] * 1000000 + portf_value['cum']
        cum_max = portf_value.groupby(pd.Grouper(freq='YE'))['value'].cummax()
        drawdown = portf_value['value']/cum_max-1
        self.MaxDrawdown = -drawdown.groupby(pd.Grouper(freq='YE')).min()
        self.MaxDrawdown.index = self.MaxDrawdown.index.year
        self.MaxDrawdown.name = 'MaxDrawdown'


def graph(df):
    df.loc[df.index[0]] = 0
    sns.set_theme(style='darkgrid', font='SimHei')
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    plt.figure(figsize=(10, 5))
    plt.title('累计收益率')
    colors = ['b', 'r']
    labels = ['Benchmark', 'Strategy']
    for i, col in enumerate(df.columns):
        plt.plot((df[col].cumsum()+1)*9000000, c=colors[i], label=labels[i])
    plt.legend()
    plt.show()


#=====================================================================
#主函数
#=====================================================================

if __name__ == '__main__':
    df = pd.read_csv(save_path+'test.csv', encoding='gbk', index_col=0, parse_dates=['date'])
    strategy_df = pd.read_csv(save_path+'strategyDF.csv', encoding='gbk', index_col=0, dtype={'YearMonth':str})
    PortfolioPerformance(df, strategy_df).setup()