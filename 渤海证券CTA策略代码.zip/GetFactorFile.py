# -*- coding: utf-8 -*-
"""
Created on 2025/3/24 16:14
@author: Wang bo
"""

import pandas as pd

file_path = '../Fundamental_Data/'
save_path = '../Result_Data/所有品种/'
factor_path = save_path + 'factor/'



class Factor:
    def __init__(self, StartDate, EndDate, kind, strategy='ma'):
        self.StartDate = StartDate
        self.EndDate = EndDate
        self.kind = kind
        self.strategy = strategy

    def info(self):
        futureDF = pd.read_csv(file_path+'主力合约信息.csv', encoding='gbk', parse_dates=['date'])
        futureDF = futureDF[futureDF['kind'] == self.kind]
        old_open = pd.read_csv(file_path+'换约后旧合约开盘价.csv', encoding='gbk')
        old_open = old_open.rename(columns={'open':'old_open'})

        Info = pd.merge(
            futureDF[['date', 'code', 'kind', 'close', 'open']],
            old_open[['code', 'old_open']],
            how='left',
            on=['code']
        ).reset_index(drop=True)
        Info['old_open'] = Info['old_open'].shift(1)
        Info.loc[Info['code']==Info['code'].shift(1), 'old_open'] = Info['open']
        Info = Info[(Info['date']>=pd.to_datetime(self.StartDate))&
                    (Info['date']<=pd.to_datetime(self.EndDate))]
        return Info.reset_index(drop=True)


    def factor(self):
        if self.strategy=='aberration':
            factorDF = pd.read_csv(factor_path+'aberration/factor_f.csv', encoding='gbk',
                                   index_col=0, parse_dates=['date'])
            factorDF = pd.DataFrame(factorDF[self.kind])
            factorDF[self.kind] = factorDF[self.kind].astype('Int64')
            factorDF[self.kind] = factorDF[self.kind]/2

        elif self.strategy=='dma':
            factorDF = pd.read_csv(factor_path+'dma/factor_dma.csv', encoding='gbk',
                                   index_col=0, parse_dates=['date'])
            factorDF = pd.DataFrame(factorDF[self.kind])
            factorDF.loc[factorDF[self.kind]>0, self.kind] = 1
            factorDF.loc[factorDF[self.kind]<0, self.kind] = -1
        elif self.strategy=='boll1':
            factorDF = pd.read_csv(factor_path+'boll/factor1_5.csv', encoding='gbk',
                                   index_col=0, parse_dates=['date'])
            factorDF = pd.DataFrame(factorDF[self.kind])

        elif self.strategy=='boll2':
            factorDF = pd.read_csv(factor_path+'boll/factor2_0.csv', encoding='gbk',
                                   index_col=0, parse_dates=['date'])
            factorDF = pd.DataFrame(factorDF[self.kind])

        elif self.strategy=='macd':
            factorDF = pd.read_csv(factor_path+'macd/factor_macd.csv', encoding='gbk',
                                   index_col=0, parse_dates=['date'])
            factorDF = pd.DataFrame(factorDF[self.kind])

        elif self.strategy=='ma':
            factorDF = pd.read_csv(factor_path+'ma/ma_5_20.csv', encoding='gbk',
                                   index_col=0, parse_dates=['date'])
            factorDF = pd.DataFrame(factorDF[self.kind])
            factorDF.loc[factorDF[self.kind]>0, self.kind] = 1
            factorDF.loc[factorDF[self.kind]<0, self.kind] = -1
        else:
            factorDF = pd.read_csv(factor_path+'ma/ma_5_20.csv', encoding='gbk',
                                   index_col=0, parse_dates=['date'])
            factorDF = pd.DataFrame(index=factorDF.index, columns=[self.kind])

        factorDF = factorDF[(factorDF.index >= pd.to_datetime(self.StartDate))&
                            (factorDF.index <= pd.to_datetime(self.EndDate))]
        return factorDF.reset_index()


if __name__ == '__main__':
    model = Factor('2015-01-01', '2024-12-31', 'A', 'aberration')
    Info = model.info()
    factor = model.factor()
    print(Info.head(10), '\n', factor.head(10))