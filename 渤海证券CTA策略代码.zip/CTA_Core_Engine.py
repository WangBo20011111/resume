import os
import pandas as pd
import sys
import time
from FactorEngine import FactorEngineTool
from WeightEngine import WeightEngine
from MAEngine import MAEngine
from BOLLEngine import BOLLEngine
from AberrationEngine import AberrationEngine
from DMAEngine import DMAEngine
from MACDEngine import MACDEngine


file_path = '../Fundamental_Data/'
save_path = '../Result_Data/所有品种/'


class CTACoreEngine:
    def __init__(self, date):
        self.date = date


    def StartWork(self):
        self.__InitDatas()
        print("__InitDatas完成")

        self.__UpdateFactors()
        print("__UpdateFactors完成")

        #self.__UpdateWeight()
        print('__UpdateWeight完成')

        #self.__UpdateTradingHold()
        print('__UpdateTradingHold完成')


    def __InitDatas(self):
        """
        :return: 为close_adj.csv增加某一天的数据
        """
        try:
            df = pd.read_csv(file_path + '主力合约信息.csv', encoding='gbk', parse_dates=['date'])
            df = df[df['date'] == pd.to_datetime(self.date)]
            df['close_adj'] = df['close'] * df['复权因子']
            df = df[['date', 'kind', 'close_adj']]
            df = df.drop_duplicates(subset=['date', 'kind'], keep='first')
            df = df.pivot(index='date', columns='kind', values='close_adj')

            if 'close_adj.csv' in os.listdir(save_path):
                close_adj = pd.read_csv(save_path + 'close_adj.csv', encoding='gbk', index_col=0, parse_dates=['date'])
            else:
                close_adj = pd.DataFrame()

            close_adj = pd.concat([close_adj, df], axis=0)
            close_adj = close_adj.reset_index()
            close_adj = close_adj.drop_duplicates(subset=['date'], keep='last')
            close_adj = close_adj.sort_values(['date'])
            close_adj.to_csv(save_path + 'close_adj.csv', encoding='gbk', index=False)
        except Exception:
            sys.exit(-1)


    def __UpdateFactors(self):
        try:
            engine = FactorEngineTool(self.date)
            engine.UpdateMaFactor()
            print("  UpdateMaFactor")
            #engine.UpdateBollFactor()
            print("  UpdateBollFactor")
            #engine.UpdateDMAFactor()
            print("  UpdateDMAFactor")
            #engine.UpdateAberrationFactor()
            print("  UpdateAberrationFactor")
            #engine.UpdateMACDFactor()
            print("  UpdateMACDFactor")
        except Exception:
            sys.exit(-1)


    def __UpdateWeight(self):
        try:
            engine = WeightEngine(self.date, ['AO', 'AU', 'JD', 'MA', 'RM', 'SA', 'SH', 'SM', 'SN'])
            engine.UpdateWeight()
        except Exception:
            sys.exit(-1)


    def __UpdateTradingHold(self):
        try:

            ma = MAEngine(self.date, 4500000)
            #ma.MAHolding()
            print('  MAHolding完成')

            boll = BOLLEngine(self.date, 4500000)
            boll.BOLLHolding1()
            print('  BOLLHolding1完成')
            boll.BOLLHolding2()
            print('  BOLLHolding2完成')

            aber = AberrationEngine(self.date, 4500000)
            aber.AberrationHolding()
            print('  AberrationHolding完成')

            dma = DMAEngine(self.date, 4500000)
            dma.DMAHolding()
            print('  DMAHolding完成')


            macd = MACDEngine(self.date, 4500000)
            macd.MACDHolding()
            print('  MACDHolding完成')

        except Exception:
            sys.exit(-1)



if __name__ == '__main__':
    time1 = time.time()
    trade_date = pd.read_csv(file_path + 'trade_date.csv', encoding='gbk', parse_dates=['date'])
    trade_date = trade_date[(trade_date['date']>=pd.to_datetime('2014-01-01')) &
                            (trade_date['date']<=pd.to_datetime('2025-03-18'))]
    for date in trade_date['date'].tolist():
        print(f'{date}开始')
        engine = CTACoreEngine(date=date)
        engine.StartWork()
        print(f'{date}完成\n')
    time2 = time.time()
    print('执行时间: ', (time2-time1)/60, 'min')