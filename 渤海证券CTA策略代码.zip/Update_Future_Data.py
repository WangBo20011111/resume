# -*- coding: utf-8 -*-
"""
Created on 2025/2/25 11:25
@author: Wang bo
"""


from jqdatasdk import *
auth('11111100076', '230wKyYd')
import os
import pandas as pd
import datetime
from tqdm import tqdm


StartDate = '2014-01-01'
EndDate = '2025-03-18'

file_path = '../Fundamental_Data/'

class JQData:
    def __init__(self, date):
        future_list = get_all_securities(types=['futures'])
        self.index_futures = future_list[future_list.index.str[-9:-5] == '8888'].index.unique().tolist()
        self.date = date
        self.dominant_df = None

    def setup(self):
        self.__update_volume()
        #print('交易量更新完成')
        self.__update_position()
        #print('持仓量更新完成')
        self.__dominant_futures()
        #print('主力合约更新完成')
        self.__update_open()
        #print('开盘价更新完成')
        self.__update_close()
        #print('收盘价更新完成')
        self.__update_new_close_before_change()
        #print('换约前新合约收盘价更新完成')
        self.__update_old_open_after_change()
        #print('换约后旧合约开盘价更新完成')
        self.__update_future_info()
        pass

    def __update_file(self, df, path):
        if os.path.exists(path):
            target = pd.read_csv(path, encoding='gbk', index_col=0, parse_dates=['date'])
        else:
            target = pd.DataFrame()
            try:
                os.makedirs(os.path.dirname(path))
            except:
                pass
        target = pd.concat([target, df], axis=0)
        target = target.reset_index()
        target = target.drop_duplicates(subset=['date', 'dominant'], keep='last')
        target = target.sort_values(['date'])
        target.to_csv(path, encoding='gbk', index=False)

    def __dominant_futures(self):
        kinds = ['A', 'AG', 'AL', 'AO', 'AP', 'AU', 'B', 'BB', 'BC', 'BR', 'BU', 'C', 'CF', 'CJ', 'CS', 'CU', 'CY',
                 'EB', 'EC', 'EG', 'FB', 'FG', 'FU', 'HC', 'I', 'J', 'JD', 'JM', 'JR', 'L', 'LC', 'LG', 'LH', 'LR', 'LU',
                 'M', 'MA', 'NI', 'NR', 'OI', 'P', 'PB', 'PF', 'PG', 'PK', 'PM', 'PP', 'PR', 'PS', 'PX',
                 'RB', 'RI', 'RM', 'RR', 'RS', 'RU', 'SA', 'SC', 'SF', 'SH', 'SI', 'SM', 'SN', 'SP', 'SR', 'SS', 'TA',
                 'UR', 'V', 'WH', 'WR', 'Y', 'ZC', 'ZN']
        dominant_future = []
        for kind in kinds:
            split = get_dominant_future(kind, date=self.date)
            dominant_future.append([self.date, kind, split])
        self.dominant_df = pd.DataFrame(dominant_future, columns=['date', 'kind', 'dominant'])
        self.dominant_df = self.dominant_df[self.dominant_df['dominant'].notna() & (self.dominant_df['dominant']!='')]
        df = self.dominant_df.copy(deep=True)
        df['date'] = pd.to_datetime(df['date'])
        self.__update_file(df.set_index('date'), file_path + 'future_dominant.csv')

    def __update_volume(self):
        volume_df = []
        for index in self.index_futures:
            split = get_price(
                index,
                start_date=self.date,
                end_date=self.date,
                frequency='daily',
                fields='volume'
            )
            split.columns = [index[:-9]]
            volume_df.append(split)
        volume_df = pd.concat(volume_df, axis=1)
        volume_df.index.name = 'date'
        self.__update_file(volume_df, file_path + '交易量.csv')

    def __update_position(self):
        position_df = []
        for index in self.index_futures:
            split = get_price(
                index,
                start_date=self.date,
                end_date=self.date,
                frequency='daily',
                fields='open_interest'
            )
            split.columns = [index[:-9]]
            position_df.append(split)
        position_df = pd.concat(position_df, axis=1)
        position_df.index.name = 'date'
        self.__update_file(position_df, file_path+'持仓量.csv')

    def __update_open(self):
        open_df = []
        for index, row in self.dominant_df.iterrows():
            code = row['dominant']
            date = row['date']
            start_date = date+' 09:00:00'
            end_date = date+' 09:01:00'
            try:
                split = get_price(code, start_date, end_date, frequency='minute')['open']
                split = pd.DataFrame(split).reset_index(drop=True)
                split['dominant'] = code
                split['date'] = date
                open_df.append(pd.DataFrame(split))
            except:
                continue
        open_df = pd.concat(open_df, axis=0).set_index('date')
        self.__update_file(open_df, file_path + '开盘价.csv')

    def __update_close(self):
        close_time = pd.read_csv(file_path + 'close_dt.csv', index_col=0, encoding='gbk', dtype={'is_next':bool, 'close_time':str})
        china_holidays = pd.read_csv(file_path + 'china_holidays.csv', index_col=0, parse_dates=['date'])

        merge = pd.merge(self.dominant_df, close_time, on='kind', how='left')
        merge['date'] = pd.to_datetime(merge['date'])
        merge['is_next'] = merge['is_next'].astype(bool)
        merge['close_date'] = None

        for index, row in merge.iterrows():
            date = row['date']
            is_next = row['is_next']
            next_date = date + datetime.timedelta(days=1)
            is_holiday = (next_date in china_holidays['date'].tolist())

            if is_next & (is_holiday==False):
                merge.at[index, 'close_date'] = next_date.strftime('%Y-%m-%d')
            elif is_holiday:
                merge.at[index, 'close_date'] = date.strftime('%Y-%m-%d')
                merge.loc[index, 'close_time'] = '15:00:00'
            else:
                merge.at[index, 'close_date'] = date.strftime('%Y-%m-%d')

        merge['close_dt'] = merge['close_date'] + ' ' + merge['close_time']
        merge = merge.dropna(subset=['close_dt'])

        close_adj = []
        for index, row in merge.iterrows():
            date = row['date']
            code = row['dominant']
            dt = row['close_dt']
            try:
                split = get_price(code, dt, dt, frequency='minute')['close']
                split = pd.DataFrame(split).reset_index(drop=True)
                if split.empty:
                    split = pd.DataFrame(get_price(
                        code,
                        date+' 15:00:00',
                        date+' 15:00:00',
                        frequency='minute'
                    )['close']).reset_index(drop=True)
                split['dominant'] = code
                split['date'] = date
                close_adj.append(pd.DataFrame(split))
            except:
                continue
        close_adj = pd.concat(close_adj, axis=0).set_index('date')
        self.__update_file(close_adj, file_path + '收盘价.csv')

    def __update_new_close_before_change(self):
        close_price = pd.read_csv(file_path + '收盘价.csv', encoding='gbk', parse_dates=['date'])
        close_time = pd.read_csv(file_path + 'close_dt.csv', index_col=0, encoding='gbk', dtype={'is_next':bool, 'close_time':str})
        tra_days = pd.read_csv(file_path + 'trading_days.csv', encoding='gbk', index_col=0, parse_dates=['trade_date'])
        china_holidays = pd.read_csv(file_path + 'china_holidays.csv', index_col=0, parse_dates=['date'])
        future_dominant = pd.read_csv(file_path + 'future_dominant.csv', encoding='gbk', parse_dates=['date'])

        merge = pd.merge(future_dominant, close_price, on=['dominant', 'date'], how='left')
        merge = merge.sort_values(['kind', 'date'])

        dominant_first = merge.drop_duplicates(['dominant'], keep='first')
        dominant_first['pre_date'] = None

        for index, row in dominant_first.iterrows():
            date = row['date']
            dominant_first.at[index, 'pre_date'] = tra_days.iloc[tra_days[tra_days['trade_date']==date].index-1].values[0][0]

        merge2 = pd.merge(dominant_first, close_time, on='kind', how='left')
        merge2['pre_date'] = pd.to_datetime(merge2['pre_date'])
        merge2['is_next'] = merge2['is_next'].astype(bool)
        merge2['close_date'] = None

        for index, row in merge2.iterrows():
            date = row['pre_date']
            is_next = row['is_next']
            next_date = date + datetime.timedelta(days=1)
            is_holiday = (next_date in china_holidays['date'].tolist())

            if is_next&(is_holiday==False):
                merge2.at[index, 'close_date'] = next_date.strftime('%Y-%m-%d')
            elif is_holiday:
                merge2.at[index, 'close_date'] = date.strftime('%Y-%m-%d')
                merge2.loc[index, 'close_time'] = '15:00:00'
            else:
                merge2.at[index, 'close_date'] = date.strftime('%Y-%m-%d')

        merge2['close_dt'] = merge2['close_date']+' '+merge2['close_time']
        merge2 = merge2.dropna(subset=['close_dt'])
        merge2['date'] = pd.to_datetime(merge2['date']).dt.strftime('%Y-%m-%d')

        close_adj = []
        for index, row in merge2.iterrows():
            code = row['dominant']
            dt = row['close_dt']
            date = str(row['date'])
            try:
                data_split = get_price(code, dt, dt, frequency='minute')['close']
                data_split = pd.DataFrame(data_split).reset_index(drop=True)
                if data_split.empty:
                    data_split = pd.DataFrame(get_price(
                        code,
                        date+' 15:00:00',
                        date+' 15:00:00',
                        frequency='minute'
                    )['close']).reset_index(drop=True)
                data_split['dominant'] = code
                data_split['date'] = row['date']
                data_split = data_split.rename(columns={'close':'new_prep'})
                close_adj.append(data_split)
            except:
                continue

        close_adj = pd.concat(close_adj, axis=0)
        close_adj.to_csv(file_path + '换约前新合约收盘价.csv', encoding='gbk', index=False)

    def __update_old_open_after_change(self):
        future_dominant = pd.read_csv(file_path+'future_dominant.csv', encoding='gbk', parse_dates=['date'])
        old_open = future_dominant.drop_duplicates(subset=['dominant'], keep='first')
        old_open = old_open.sort_values(['kind', 'date'])
        old_open['date'] = pd.to_datetime(old_open['date']).dt.strftime('%Y-%m-%d')
        old_open['post_date'] = old_open['date'].shift(-1)

        open_adj = []
        for index, row in old_open.iterrows():
            code = row['dominant']
            date = row['post_date']
            start_date = str(date)+' 09:00:00'
            end_date = str(date)+' 09:01:00'
            try:
                data_split = get_price(code, start_date, end_date, frequency='minute')['open']
                data_split = pd.DataFrame(data_split).reset_index(drop=True)
                data_split['code'] = code[:-5]
                data_split['date'] = str(date)
                open_adj.append(pd.DataFrame(data_split))
            except:
                continue

        open_adj = pd.concat(open_adj, axis=0)
        open_adj.to_csv(file_path + '换约后旧合约开盘价.csv', encoding='gbk', index=False)


    def __update_future_info(self):
        close_df = pd.read_csv(file_path + '收盘价.csv', encoding='gbk', parse_dates=['date'])
        open_df = pd.read_csv(file_path + '开盘价.csv', encoding='gbk', parse_dates=['date'])
        new_prep = pd.read_csv(file_path + '换约前新合约收盘价.csv', encoding='gbk', parse_dates=['date'])
        dominant_df = pd.read_csv(file_path + 'future_dominant.csv', encoding='gbk', parse_dates=['date'])

        dominant_df = dominant_df[dominant_df['date'] <= pd.to_datetime(self.date)]
        close_df = close_df[close_df['date'] <= pd.to_datetime(self.date)]
        open_df = open_df[open_df['date'] <= pd.to_datetime(self.date)]

        merge = pd.merge(dominant_df, close_df, on=['dominant','date'], how='left')
        merge = merge.sort_values(['kind','date']).reset_index(drop=True)
        merge['old_prep'] = merge.groupby('kind')['close'].shift(1)

        new_prep = pd.merge(new_prep, merge[['dominant','date','kind','old_prep']], on=['dominant', 'date'], how='left')
        new_prep['ratio'] = new_prep['old_prep']/new_prep['new_prep']
        new_prep['ratio'] = new_prep['ratio'].fillna(1)
        new_prep['复权因子'] = new_prep.groupby('kind')['ratio'].cumprod()

        merge = pd.merge(merge, new_prep[['dominant', '复权因子']], on=['dominant'], how='left')
        merge = pd.merge(merge, open_df, on=['date','dominant'], how='left')
        merge['code'] = merge['dominant'].str[:-5]
        merge = merge[['date','code','dominant','kind','open','close','复权因子']]
        self.__update_file(merge.set_index('date'), file_path + '主力合约信息.csv')
        pass



if __name__ == "__main__":
    trade_date = pd.read_csv(file_path+'trade_date.csv', encoding='gbk', parse_dates=['date'])
    trade_date = trade_date[(trade_date['date']>=pd.to_datetime('2025-01-01')) & (trade_date['date']<=pd.to_datetime('2025-04-30'))]
    for date in tqdm(trade_date['date'].astype(str).tolist(), desc='更新每日数据'):
        model = JQData(date)
        model.setup()