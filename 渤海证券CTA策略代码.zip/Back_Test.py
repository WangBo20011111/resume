# -*- coding: utf-8 -*-
"""
Created on 2025/2/27 19:14
@author: Wang bo
"""

import pandas as pd
from matplotlib import pyplot as plt
from pylab import mpl
import seaborn as sns


mpl.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


file_path = '../Fundamental_Data/'
save_path = '../Result_Data/所有品种/'
factor_path = save_path + 'factor/'


#=============================================================
#回测
#=============================================================

def BackTest(factorDF, Funds=1000000):
    df = factorDF
    df['signal'] = df['signal'].fillna(0)
    condition1 = (df['signal']!=df['signal'].shift(1))
    condition2 = (df['code']!=df['code'].shift(1))

    #更新每天的市场价值
    df.loc[condition1|condition2, 'cost'] = df['open']
    #df.loc[0, 'cost'] = np.nan
    df['pos'] = (Funds/df['cost']) * df['signal']
    #df.loc[0, 'pos'] = 0

    df['cost'] = df['cost'].ffill()
    df['pos'] = df['pos'].ffill()

    df['profit'] = df['pos']*(df['close']-df['cost'])
    #df.loc[0, 'profit'] = 0
    df['profit'] = df['profit'].fillna(0)
    df.loc[(condition1|condition2), 'settle'] = df['pos'].shift(1) * (df['old_open']-df['cost'].shift(1))
    df['settle'] = df['settle'].cumsum()
    df['settle'] = df['settle'].ffill()
    df['settle'] = df['settle'].fillna(0)

    df['value'] = Funds + df['profit'] + df['settle']
    valueDF = df[['date', 'signal', 'kind', 'value', 'profit','settle' ]]
    return valueDF



def ValueFigure(df, name):
    sns.set_theme(style='darkgrid', font='SimHei', rc={'axes.unicode_minus': False})
    plt.figure(figsize=(10,5))
    plt.title(name, fontsize=12)
    colors = ['r', 'b'] + sns.color_palette("husl", n_colors=len(df.columns)-2)
    ax = plt.gca()
    ax2 = ax.twinx()

    for i, col in enumerate(df.columns[2:], start=2):
        ax.plot(df[col], color=colors[i], label=col, linewidth=0.5)
    for i, col in enumerate(df.columns[:2]):
        ax2.plot(df[col], c=colors[i],  label=col)

    ax.set_xlabel('date', fontsize=12)
    ax2.set_ylabel('value', fontsize=12)
    ax.set_ylabel('数量', fontsize=12)
    ax.grid(False)
    ax2.grid(False)
    lines1, labels1 = ax.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax.legend(lines1+lines2, labels1+labels2, loc='best')

    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.savefig(save_path+'/figure/' + name + '.png', dpi=300, bbox_inches='tight')
    plt.show()




#=============================================================
# 主函数
#=============================================================

if  __name__ == "__main__":
    df = pd.read_csv(save_path+'test.csv', encoding='gbk', index_col=0, parse_dates=['date'])












