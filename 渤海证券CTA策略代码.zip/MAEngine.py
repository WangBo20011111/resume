﻿import pandas as pd
import os

file_path = '../Fundamental_Data/'
save_path = '../Result_Data/所有品种/'
factor_path = save_path + 'factor/'
weight_path = save_path + 'weight/'


class MAEngine:
    def __init__(self, date, total_fund):
        self.date = date
        self.total_fund = total_fund


    def __UpdateFile(self, path, df):
        if os.path.exists(path):
            target = pd.read_csv(path, encoding='gbk', parse_dates=['date'])
        else:
            target = pd.DataFrame()
            try:
                os.makedirs(os.path.dirname(path))
            except:
                pass
        target = pd.concat([target, df], axis=0)
        if 'kind' in target.columns:
            target = target.drop_duplicates(subset=['date','kind'], keep='last')
            target = target.sort_values(['date','kind'])
        else:
            target = target.drop_duplicates(subset=['date'], keep='last')
            target = target.sort_values(['date'])
        target.to_csv(path, encoding='gbk', index=False)


    def MAHolding(self):
        code_list = ['RU', 'CF','JM']
        factorDF = pd.read_csv(factor_path + '/ma/ma_5_20.csv', index_col=0, encoding='gbk', parse_dates=['date'])
        weightDF = pd.read_csv(weight_path + 'weight.csv', index_col=0, encoding='gbk', parse_dates=['date'])
        futureDF = pd.read_csv(file_path + '主力合约信息.csv', encoding='gbk', parse_dates=['date'])

        for i in code_list:
            factor = factorDF[factorDF.index == pd.to_datetime(self.date)][i].values[0]
            weight = weightDF[(weightDF.index == pd.to_datetime(self.date)) &
                              (weightDF['kind'] == i)]['weight_adj'].values[0]
            code = futureDF[(futureDF['date'] == pd.to_datetime(self.date)) &
                            (futureDF['kind'] == i)]['code'].values[0]

            if factor == 0:
                pass
            else:
                if factor > 0:
                    flag = 1 ###多仓
                else:
                    flag = -1 ###空仓
                fund = self.total_fund * weight
                hold_code = code
                tmpDF = pd.DataFrame([[self.date, hold_code, flag, fund, i]],
                                     columns=['date','code','flag','fund','kind'])
                self.__UpdateFile(save_path + 'shareholding/shareholding.csv', tmpDF)


if __name__ == '__main__':
    date = input("请输入日期(YYYY-MM-DD): ")
    total_fund = input('请输入总资金: ')
    engine = MAEngine(date, total_fund)
    engine.MAHolding()
