# -*- coding: utf-8 -*-
"""
Created on 2025/4/21 13:01
@author: Wang bo
"""

import pandas as pd
import numpy as np
from matplotlib import pyplot as plt

FilePath = 'D:/PycharmProjects/渤海证券/CTA/Fundamental_Data/高频数据/汇总/'
SavePath = 'D:/PycharmProjects/渤海证券/CTA/Result_Data/高频结果/'

class Signal:
    def __init__(self, factor_df, interval, num):
        self.signal_df = None
        self.factor_df = factor_df
        self.interval = interval
        self.num = num

    def __signal(self, tmp):
        s = pd.Series(0, index=tmp.index)
        tmp = tmp.dropna()
        conflict_dict = {
            "NI":"SS",
            "SS":"NI",
            "J":"JM",
            "JM":"J",
            "RB":"HC",
            "HC":"RB"
        }
        if len(tmp) < self.num * 2:
            print(f'{tmp.name}品种小于{self.num*2}个')

        tmp = tmp.rank(method='first', ascending=False).astype(int)
        upper_selected = []
        lower_selected = []
        for i in range(1, len(tmp)+1):
            if len(upper_selected) > self.num and len(lower_selected) > self.num:
                break
            if len(upper_selected) <= self.num:
                idx = tmp[tmp == i].index
                if idx in conflict_dict and conflict_dict[idx] in upper_selected:
                    pass
                else:
                    upper_selected.append(idx)
            if len(lower_selected) <= self.num:
                idx = tmp[tmp == len(tmp)-i+1].index
                if idx in conflict_dict and conflict_dict[idx] in lower_selected:
                    pass
                else:
                    lower_selected.append(idx)
        s.loc[upper_selected] = 1
        s.loc[lower_selected] = -1
        return s

    def setup(self):
        self.signal_df = self.factor_df.apply(self.__signal, axis=1)
        self.signal_df['Serial_Number'] = range(0, len(self.signal_df))
        self.signal_df.loc[self.signal_df['Serial_Number'] % self.interval != 0] = np.nan
        self.signal_df = self.signal_df.ffill()
        return self.signal_df




class Backtest:
    def __init__(self, Data, funds=1000000):
        self.funds = funds
        self.Data = Data
        self.change_signal = (self.Data['signal']!=self.Data['signal'].shift(1))

    def update_cost(self):
        self.Data.loc[self.change_signal, 'cost'] = self.Data['price']
        self.Data['cost'] = self.Data['cost'].ffill()

    def update_position(self):
        self.Data['position'] = self.funds / self.Data['cost'] * self.Data['signal']

    def update_unrealized(self):
        self.Data['cum_unrealized'] = (self.Data['price'] - self.Data['cost']) * self.Data['position']

    def update_realized(self):
        self.Data.loc[self.change_signal, 'cum_realized'] = (self.Data['cost'] - self.Data['price'].shift(1)) * self.Data['position'].shift(1)
        self.Data['cum_realized'] = self.Data['realized'].cumsum().ffill()

    def update_profit(self):
        self.Data['cum_profit'] = self.Data['cum_unrealized'] + self.Data['cum_realized']

    def update_market_value(self):
        self.Data['market_value'] = self.funds + self.Data['cum_profit']

    def daily_freq(self):
        self.Data = self.Data.groupby('date_adj')['market_value'].tail(-1)

    def setup(self):
        self.update_cost()
        self.update_position()
        self.update_unrealized()
        self.update_realized()
        self.update_profit()
        self.update_market_value()
        self.daily_freq()
        return self.Data['market_value']



def graph(df):
    plt.figure(figsize=(10,5))
    for col in df.columns:
        plt.plot(df[col], c='r', label=col)
    plt.legend()
    plt.show()



if __name__ == '__main__':
    def adjust_date(df):
        df['date'] = df.index.strftime('%Y-%m-%d')
        df['Time'] = df.index.strftime('%H%M%S')

        FuturesDate = pd.DataFrame(df['date']).drop_duplicates(keep='last').reset_index(drop=True)
        FuturesDate['FuturesDate'] = FuturesDate['date']
        TradeDate = pd.read_csv(FilePath+'trade_date.csv', encoding='gbk')
        TradeDate['date'] = pd.to_datetime(TradeDate['date']).dt.strftime('%Y-%m-%d')
        TradeDate['TradeDate'] = TradeDate['date']
        MergeDate = pd.merge(FuturesDate, TradeDate, on='date', how='outer')

        def find_next_date(MergeDate, date):
            idx = MergeDate.index[MergeDate['FuturesDate']==date][0]
            date_adj = np.nan
            for i in range(1, 30):
                if pd.notna(MergeDate.loc[idx+i, 'TradeDate']):
                    date_adj = MergeDate.loc[idx+i, 'TradeDate']
                    break
            return date_adj
        mapping = {d:find_next_date(MergeDate, d) for d in df['date'].unique()}
        condition = (df['Time']<='153000')&(df['Time']>='085900')
        df['date_adj'] = np.where(condition, df['date'], df['date'].map(mapping))
        return df


    factor_df = pd.read_csv(SavePath+'factor.csv')
    price_df = pd.read_csv(SavePath+'price.csv')
    price_df = adjust_date(price_df)
    signal_df = Signal(factor_df, 18, 5).setup()

    mv_df = []
    for col in signal_df.columns:
        merge  = pd.merge(signal_df[col], price_df[[col, 'date_adj']], on='time', how='left')
        merge.columns = ['signal', 'price', 'date_adj']
        mv_col = Backtest(merge)
        mv_col.name = col
        mv_df.append(mv_col)
    mv_df = pd.concat(mv_df, axis=1)

    mv_df['portfolio'] = mv_df.sum(axis=1)










