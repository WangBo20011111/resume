# -*- coding: utf-8 -*-
"""
Created on 2025/3/10 14:25
@author: Wang bo
"""
from multiprocessing import Pool
import pandas as pd
from matplotlib import pyplot as plt
import numpy as np
from pandas.tseries.offsets import MonthEnd
from GetFactorFile import Factor
from Back_Test import BackTest
import Portfolio_Performance as pp
from tqdm import tqdm

pd.set_option('display.max_seq_items', None)
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
pd.options.mode.chained_assignment = None  # 关闭链式赋值警告（全局）

file_path = '../Fundamental_Data/'
save_path = '../Result_Data/所有品种/'
factor_path = save_path + 'factor/'


#=====================================================================
#资产组合回撤
#=====================================================================

def TradeSelect(Num, signal):
    """
    :param Num: 选取的组合品种数量
    :param signal: '持仓量'/'交易量'
    :return:
    """
    RetYearlyAll = pd.read_csv(save_path+'单品种所有策略的年收益率.csv', encoding='gbk', index_col=0)
    RetYearlyAll['Strategy'] = RetYearlyAll.index.str[:-4]

    BestStrategy = RetYearlyAll.copy(deep=True)
    BestStrategy = BestStrategy.groupby('Strategy').shift(1)
    BestStrategy['Year'] = BestStrategy.index.str[-4:]
    BestStrategy['Strategy'] = BestStrategy.index.str[:-4]
    BestStrategy = BestStrategy.melt(id_vars=['Year', 'Strategy'], value_vars=BestStrategy.columns[:-2],
                                     var_name='kind', value_name='RetYearly')
    BestStrategy = (BestStrategy.sort_values(['Year', 'kind', 'RetYearly'], ascending=[True, True, False]).
                    groupby(['Year', 'kind']).head(1).
                    dropna())

    volumeDF = pd.read_csv(file_path+signal+'.csv', encoding='gbk', index_col=0, parse_dates=['date'])
    #DropList = ['T', 'TC', 'IC', 'IH', 'IF', 'ZC', 'TF', 'TS', 'IM', 'TL', 'SC', 'NR', 'LU', 'BC', 'EC', 'SI', 'LC',
                #'CS', 'FB', 'RS', 'PM', 'WH', 'RI', 'JR', 'LR', 'BB', 'CJ','WR' , 'RR']
    DropList = ['T', 'TC', 'IC', 'IH', 'IF', 'ZC', 'TF', 'TS', 'IM', 'TL', 'SC', 'LU', 'BC',
                'CS', 'FB', 'RS', 'PM', 'WH', 'RI', 'JR', 'LR', 'BB', 'CJ', 'WR', 'RR']
    volumeDF = volumeDF.drop(columns=DropList)
    volumeDF['YearMonth'] = volumeDF.index.strftime('%Y%m')
    volumeDF = volumeDF.groupby('YearMonth').sum()
    volumeDF = volumeDF*3/(volumeDF.shift(1) + volumeDF.shift(2) + volumeDF.shift(3))
    volumeDF = volumeDF.shift(1)
    volumeDF[np.isinf(volumeDF)] = np.nan

    conflict_dict = {
        "NI":"SS",
        "SS":"NI",
        "J":"JM",
        "JM":"J",
        "RB":"HC",
        "HC":"RB"
    }
    TradeList = []
    for month in volumeDF.index:
        selected = []
        VolumeRatio = []
        row = volumeDF.loc[month].dropna().sort_values(ascending=False)
        for kind, value in row.items():
            if kind in conflict_dict and conflict_dict[kind] in selected:
                continue
            #if value<1:
                #continue
            selected.append(kind)
            VolumeRatio.append(value)

            if len(selected)==Num:
                break
        TradeList.append(pd.DataFrame({'YearMonth':month, 'kind':selected, 'Volume':VolumeRatio}))
        if len(selected)==0:
            TradeList.append(pd.DataFrame({'YearMonth':month, 'kind':[np.nan], 'Volume':[np.nan]}))
    TradeList = pd.concat(TradeList, axis=0)
    TradeList['Year'] = TradeList['YearMonth'].str[:4]
    TradeList = pd.merge(TradeList, BestStrategy, on=['Year', 'kind'], how='left')
    TradeList['Strategy'] = TradeList['Strategy'].fillna('ma')
    TradeList = pd.pivot(TradeList, index='YearMonth', columns='kind', values='Strategy')
    TradeList = TradeList.loc[:, TradeList.columns.notna()]
    TradeList = TradeList[TradeList.index.str[:4]!=TradeList.index[0][:4]]

    TradeSelect = []
    for i in range(0,3):
        InitDate = (pd.to_datetime(TradeList.index[0], format='%Y%m') + pd.DateOffset(months=i)).replace(day=1)
        tmp = TradeList[pd.to_datetime(TradeList.index, format='%Y%m') >= InitDate]
        for j in range(0, len(tmp), 3):
            if j+2<len(tmp):
                tmp.iloc[j+1:j+3] = tmp.iloc[j].values
        TradeSelect.append(tmp)
    return TradeList, TradeSelect


def dominant_factor():
    def count_signal(row):
        count1 = row.value_counts().get(1, 0)
        count_neg1 = row.value_counts().get(-1, 0)
        if count1>=3:
            return 1
        elif count_neg1>=3:
            return -1
        else:
            return 0

    KindList = pd.unique(pd.read_csv(file_path+'future_dominant.csv', encoding='gbk')['kind'])
    factorDF = pd.DataFrame()
    for kind in KindList:
        factor = pd.DataFrame()
        for strategy in ['aberration', 'boll2', 'dma', 'ma', 'boll1']:
            model = Factor('1111-01-01', '2999-12-31', kind, strategy)
            tmp = model.factor()
            tmp.columns = ['date', strategy]
            if factor.empty:
                factor = tmp
            else:
                factor = pd.merge(factor, tmp, on=['date'], how='left')
        factor[kind] = factor.set_index('date').apply(count_signal, axis=1).values
        if factorDF.empty:
            factorDF = factor[['date',kind]]
        else:
            factorDF = pd.merge(factorDF, factor[['date',kind]], on=['date'], how='left')
    factorDF.to_csv(factor_path + 'DominantFactor.csv', encoding='gbk', index=False)
    pass


def cross(Num):
    RetYearlyAll = pd.read_csv(save_path+'单品种所有策略的年收益率.csv', encoding='gbk', index_col=0)
    RetYearlyAll['Strategy'] = RetYearlyAll.index.str[:-4]

    BestStrategy = RetYearlyAll.copy(deep=True)
    BestStrategy = BestStrategy.groupby('Strategy').shift(1)
    BestStrategy['Year'] = BestStrategy.index.str[-4:]
    BestStrategy['Strategy'] = BestStrategy.index.str[:-4]
    BestStrategy = BestStrategy.melt(id_vars=['Year', 'Strategy'], value_vars=BestStrategy.columns[:-2],
                                     var_name='kind', value_name='RetYearly')
    BestStrategy = (BestStrategy.sort_values(['Year', 'kind', 'RetYearly'], ascending=[True, True, False]).
                    groupby(['Year', 'kind']).head(1).
                    dropna())
    #DropList = ['T', 'TC', 'IC', 'IH', 'IF', 'ZC', 'TF', 'TS', 'IM', 'TL', 'SC', 'NR', 'LU', 'BC', 'EC', 'SI', 'LC',
    #'CS', 'FB', 'RS', 'PM', 'WH', 'RI', 'JR', 'LR', 'BB', 'CJ','WR' , 'RR']
    DropList = ['T', 'TC', 'IC', 'IH', 'IF', 'ZC', 'TF', 'TS', 'IM', 'TL', 'SC', 'LU', 'BC',
                'CS', 'FB', 'RS', 'PM', 'WH', 'RI', 'JR', 'LR', 'BB', 'CJ', 'WR', 'RR']

    holding = pd.read_csv(file_path+'持仓量.csv', encoding='gbk', index_col=0, parse_dates=['date'])
    holding = holding.drop(columns=DropList)
    holding['YearMonth'] = holding.index.strftime('%Y%m')
    holding = holding.groupby('YearMonth').sum()
    holding = holding*3/(holding.shift(1)+holding.shift(2)+holding.shift(3))
    holding = holding.shift(1)
    holding[np.isinf(holding)] = np.nan

    volume = pd.read_csv(file_path+'交易量.csv', encoding='gbk', index_col=0, parse_dates=['date'])
    volume = volume.drop(columns=DropList)
    volume['YearMonth'] = volume.index.strftime('%Y%m')
    volume = volume.groupby('YearMonth').sum()
    volume = volume*3/(volume.shift(1)+volume.shift(2)+volume.shift(3))
    volume = volume.shift(1)
    volume[np.isinf(volume)] = np.nan

    conflict_dict = {
        "NI":"SS",
        "SS":"NI",
        "J":"JM",
        "JM":"J",
        "RB":"HC",
        "HC":"RB"
    }
    TradeList1 = []
    for month in holding.index:
        selected = []
        HoldingRatio = []
        row = holding.loc[month].dropna().sort_values(ascending=False)
        for kind, value in row.items():
            if kind in conflict_dict and conflict_dict[kind] in selected:
                continue
            selected.append(kind)
            HoldingRatio.append(value)

            if len(selected)==Num:
                break
        TradeList1.append(pd.DataFrame({'YearMonth':month, 'kind':selected, 'holding':HoldingRatio}))
    TradeList1 = pd.concat(TradeList1, axis=0)
    TradeList1 = pd.pivot(TradeList1, index='YearMonth', columns='kind', values='holding')
    TradeList1.to_csv(save_path+'test_TradeList1.csv', encoding='gbk')

    TradeList2 = []
    for month in volume.index:
        selected = []
        VolumeRatio = []
        row = volume.loc[month].dropna().sort_values(ascending=False)
        for kind, value in row.items():
            if kind in conflict_dict and conflict_dict[kind] in selected:
                continue
            selected.append(kind)
            VolumeRatio.append(value)

            if len(selected)==Num:
                break
        TradeList2.append(pd.DataFrame({'YearMonth':month, 'kind':selected, 'volume':VolumeRatio}))
    TradeList2 = pd.concat(TradeList2, axis=0)
    TradeList2 = pd.pivot(TradeList2, index='YearMonth', columns='kind', values='volume')
    TradeList2.to_csv(save_path+'test_TradeList2.csv', encoding='gbk')

    TradeList = pd.DataFrame()
    for index, row in TradeList1.iterrows():
        row1 = row.dropna().index
        row2 = TradeList2.loc[index].dropna().index
        common = row1.intersection(row2).tolist()
        tmp = pd.DataFrame({'YearMonth':index, 'kind':common})
        if len(common)==0:
            tmp = pd.DataFrame({'YearMonth':index, 'kind':[np.nan]})
        TradeList = pd.concat([TradeList, tmp], axis=0)
    TradeList['Year'] = TradeList['YearMonth'].str[:4]
    TradeList = pd.merge(TradeList, BestStrategy, on=['Year', 'kind'], how='left')
    TradeList['Strategy'] = TradeList['Strategy'].fillna('ma')
    TradeList = pd.pivot(TradeList, index='YearMonth', columns='kind', values='Strategy')
    TradeList = TradeList[TradeList.index.str[:4]!=TradeList.index[0][:4]]
    TradeList = TradeList.drop(columns=[np.nan])


    TradeSelect = []
    for i in range(0, 3):
        InitDate = (pd.to_datetime(TradeList.index[0], format='%Y%m')+pd.DateOffset(months=i)).replace(day=1)
        tmp = TradeList[pd.to_datetime(TradeList.index, format='%Y%m')>=InitDate]
        for j in range(0, len(tmp), 3):
            if j+2<len(tmp):
                tmp.iloc[j+1:j+3] = tmp.iloc[j].values
        TradeSelect.append(tmp)
    return TradeList, TradeSelect




def market_value(Paras):
    StrategyCol, which = Paras
    kind = StrategyCol.name
    TradeMonths = StrategyCol.dropna()
    Start = pd.to_datetime(StrategyCol.index[0]+'01', format='%Y%m%d')
    End = pd.to_datetime(StrategyCol.index[-1]+'01', format='%Y%m%d')
    End = pd.to_datetime(End+MonthEnd(0))
    Info = Factor(Start, End, kind).info()
    factor = Factor(Start, End, kind, 'ma').factor()
    #factor = pd.read_csv(factor_path + 'DominantFactor.csv', encoding='gbk', parse_dates=['date'])
    '''
    try:
        factor = []
        for index, value in StrategyCol.dropna().items():
            Now = pd.to_datetime(index + '01', format='%Y%m%d')
            Start = Now - pd.DateOffset(months=1)
            End = pd.to_datetime(Now + MonthEnd(0))
            tmp = Factor(Start, End, kind, strategy=value).factor()
            factor.append(tmp)
        factor = pd.concat(factor, axis=0)
        factor = factor.drop_duplicates(subset=['date'], keep='first')
    except:
        factor = pd.DataFrame()
    '''
    try:
        df = pd.merge(Info, factor[['date', kind]], on=['date'], how='left')
        df['signal'] = df[kind].shift(1)
        if which != 'Benchmark':
            df.loc[~df['date'].dt.strftime('%Y%m').isin(TradeMonths.index), 'signal'] = 0
        else:
            df.loc[~df['signal'].isna(), 'signal'] = 1
            df.loc[~df['date'].dt.strftime('%Y%m').isin(TradeMonths.index), 'signal'] = 0
        value_df = BackTest(df)
    except:
        value_df = pd.DataFrame()
    return value_df



def old_portfolio(portfolio, signal):
    if portfolio=='组合1':
        TradeList = pd.DataFrame({
            'J':'aberration',
            'AL':'boll1',
            'TA':'boll2',
            'BU':'boll2',
            'P':'boll2',
            'I':'dma',
            'RB':'macd',
            'C':'ma',
            'Y':'ma'
        },
            index=pd.date_range("2016-01-01", "2025-12-31", freq="MS").strftime("%Y%m").tolist()
        )
    else:
        TradeList = pd.DataFrame({
            'V':'aberration',
            'HC':'boll2',
            'FG':'boll2',
            'M':'boll2',
            'CU':'dma',
            'RU':'ma',
            'CF':'ma',
            'JM':'ma'
        },
            index=pd.date_range("2016-01-01", "2025-12-31", freq="MS").strftime("%Y%m").tolist()
        )
    if signal=='原策略':
        result = TradeList
    elif signal=='去年最优策略':
        TradeList.index.name = 'YearMonth'
        RetYearlyAll = pd.read_csv(save_path+'单品种所有策略的年收益率.csv', encoding='gbk', index_col=0)
        RetYearlyAll['Strategy'] = RetYearlyAll.index.str[:-4]

        BestStrategy = RetYearlyAll.copy(deep=True)
        BestStrategy = BestStrategy.groupby('Strategy').shift(1)
        BestStrategy['Year'] = BestStrategy.index.str[-4:]
        BestStrategy['Strategy'] = BestStrategy.index.str[:-4]
        BestStrategy = BestStrategy.melt(id_vars=['Year', 'Strategy'], value_vars=BestStrategy.columns[:-2],
                                         var_name='kind', value_name='RetYearly')
        BestStrategy = (BestStrategy.sort_values(['Year', 'kind', 'RetYearly'], ascending=[True, True, False]).
                        groupby(['Year', 'kind']).head(1).
                        dropna())
        TradeList = pd.melt(TradeList.reset_index(), id_vars='YearMonth', value_vars=TradeList.columns,
                            var_name='kind', value_name='strategy')
        TradeList['Year'] = TradeList['YearMonth'].str[:4]
        TradeList = pd.merge(TradeList, BestStrategy, on=['Year', 'kind'], how='left')
        TradeList['Strategy'] = TradeList['Strategy'].fillna('ma')
        TradeList = pd.pivot(TradeList, index='YearMonth', columns='kind', values='Strategy')
        result = TradeList
    return result



if __name__ == '__main__':
    #dominant_factor()
    Select, Select_3m = cross(5)
    #Select, Select_3m = TradeSelect(5, '持仓量')
    stack = pd.concat(Select_3m, axis=1)

    #Select = old_portfolio('组合2','去年最优策略')

    for TradeList in [x for x in Select_3m]+[stack, Select]:
        if TradeList is Select_3m[2]:
            TradeList.to_csv(save_path+'TradeList.csv', encoding='gbk')
            #'''
            Paras = []
            for j in range(TradeList.shape[1]):
                StrategyCol = TradeList.iloc[:, j]
                Paras.append([StrategyCol, 'Benchmark'])
            print('Paras构建完成')
            with Pool(5) as pool:
                results = list(tqdm(pool.imap(market_value, Paras), total=len(Paras), desc="整体进度"))
            results = pd.concat(results,axis=0)
            print('---------------Benchmark-----------------')
            retBL = pp.PortfolioPerformance(results, TradeList).setup()
            print('-----------------------------------------')
            #'''

            Paras = []
            for j in range(TradeList.shape[1]):
                StrategyCol = TradeList.iloc[:, j]
                Paras.append([StrategyCol, 'Strategy'])
            print('Paras构建完成')
            with Pool(5) as pool:
                results = list(tqdm(pool.imap(market_value, Paras), total=len(Paras), desc="整体进度"))
            results = pd.concat(results, axis=0)
            print('---------------Strategy-----------------')
            retST = pp.PortfolioPerformance(results, TradeList).setup()
            print('-----------------------------------------')

            #'''
            graph_df = pd.concat([retBL['ret'], retST['ret']], axis=1)
            graph_df.columns = ['Benchmark','Strategy']
            pp.graph(graph_df)
            #'''