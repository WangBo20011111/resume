
import pandas as pd
import os
print(os.getcwd())

file_path = '../Fundamental_Data/'
save_path = '../Result_Data/所有品种/'
factor_path = save_path + 'factor/'

for path in [save_path, factor_path]:
    if not os.path.exists(path):
        os.makedirs(path)


class FactorEngineTool:
    def __init__(self, date):
        self.date = date


    def __UpdateFactorFile(self, path, df):
        """
        :param path: 需要更新的表格
        :param df: 添加的数据
        :return: 更新后的表格
        """
        if os.path.exists(path):
            target = pd.read_csv(path, encoding='gbk', index_col=0, parse_dates=['date'])
        else:
            target = pd.DataFrame()
            try:
                os.makedirs(os.path.dirname(path))
            except:
                pass
        target = pd.concat([target, df], axis=0)
        target = target.reset_index()
        target = target.drop_duplicates(subset=['date'], keep='last')
        target = target.sort_values(['date'])
        target.to_csv(path, encoding='gbk', index=False)


    def UpdateMaFactor(self):
        """
        :return: 添加的Ma数据
        """
        try:
            df = pd.read_csv(save_path+'close_adj.csv', encoding='gbk', index_col=0, parse_dates=['date'])
            df_s = df.rolling(window=5).mean()
            df_l = df.rolling(window=20).mean()
            res = df_s - df_l
            res = res[res.index == pd.to_datetime(self.date)]
            self.__UpdateFactorFile(factor_path + 'ma/ma_5_20.csv', res)
        except Exception as e:
            raise e


    def UpdateBollFactor(self):
        """
        :return: 添加Boll数据
        """
        try:
            df = pd.read_csv(save_path+'close_adj.csv', encoding='gbk', index_col=0, parse_dates=['date'])
            std = df.rolling(window=20).std()
            df_mid = df.rolling(window=20).mean()
            df_high = df_mid + std*1.5
            df_low = df_mid - std*1.5

            df_mid = df_mid[df_mid.index == pd.to_datetime(self.date)]
            df_high = df_high[df_high.index==pd.to_datetime(self.date)]
            df_low = df_low[df_low.index==pd.to_datetime(self.date)]
            std = std[std.index==pd.to_datetime(self.date)]
            self.__UpdateFactorFile(factor_path + 'boll/mid_20_1.5.csv', df_mid)
            self.__UpdateFactorFile(factor_path + 'boll/high_20_1.5.csv', df_high)
            self.__UpdateFactorFile(factor_path + 'boll/low_20_1.5.csv', df_low)
            self.__UpdateFactorFile(factor_path + 'boll/std_20_1.5.csv', std)

            df_mid = df.rolling(window=20).mean()
            std = df.rolling(window=20).std()
            df_high = df_mid + std * 2
            df_low = df_mid - std * 2

            df_mid = df_mid[df_mid.index == pd.to_datetime(self.date)]
            df_high = df_high[df_high.index == pd.to_datetime(self.date)]
            df_low = df_low[df_low.index == pd.to_datetime(self.date)]
            std = std[std.index == pd.to_datetime(self.date)]
            self.__UpdateFactorFile(factor_path + 'boll/mid_20_2.csv', df_mid)
            self.__UpdateFactorFile(factor_path + 'boll/high_20_2.csv', df_high)
            self.__UpdateFactorFile(factor_path + 'boll/low_20_2.csv', df_low)
            self.__UpdateFactorFile(factor_path + 'boll/std_20_2.csv', std)
        except Exception as e:
            raise e


    def UpdateDMAFactor(self):
        """
        :return: 添加DMA数据
        """
        try:
            df = pd.read_csv(save_path+'close_adj.csv', encoding='gbk', index_col=0, parse_dates=['date'])
            df_s = df.rolling(window=10).mean()
            df_l = df.rolling(window=50).mean()
            dma = df_s - df_l
            ama = dma.rolling(window=10).mean()
            res = dma - ama

            dma = dma[dma.index == pd.to_datetime(self.date)]
            ama = ama[ama.index == pd.to_datetime(self.date)]
            res = res[res.index == pd.to_datetime(self.date)]
            self.__UpdateFactorFile(factor_path + 'dma/dma_10_50_10.csv', dma)
            self.__UpdateFactorFile(factor_path + 'dma/ama_10_50_10.csv', ama)
            self.__UpdateFactorFile(factor_path + 'dma/res_10_50_10.csv', res)
        except Exception as e:
            raise e


    def UpdateAberrationFactor(self):
        """
        :return: 更新Aberration数据
        """
        try:
            df = pd.read_csv(save_path+'close_adj.csv', encoding='gbk', index_col=0, parse_dates=['date'])
            df_mid = df.rolling(window=20).mean()
            std = df.rolling(window=20).std()
            df_high = df_mid + std*2
            df_low = df_mid - std*2

            std = std[pd.to_datetime(std.index) == pd.to_datetime(self.date)]
            df_mid = df_mid[df_mid.index == pd.to_datetime(self.date)]
            df_high = df_high[df_high.index == pd.to_datetime(self.date)]
            df_low = df_low[df_low.index == pd.to_datetime(self.date)]
            self.__UpdateFactorFile(factor_path + 'aberration/mid_20_2.csv', df_mid)
            self.__UpdateFactorFile(factor_path + 'aberration/std_20_2.csv', std)
            self.__UpdateFactorFile(factor_path + 'aberration/high_20_2.csv', df_high)
            self.__UpdateFactorFile(factor_path + 'aberration/low_20_2.csv', df_low)
        except Exception as e:
            raise e


    def UpdateMACDFactor(self):
        try:
            df = pd.read_csv(save_path+'close_adj.csv', encoding='gbk', index_col=0, parse_dates=['date'])
            data1 = pd.DataFrame.ewm(df, span=12, adjust=False).mean()
            data2 = pd.DataFrame.ewm(df, span=26, adjust=False).mean()
            dif = data1 - data2
            dea = pd.DataFrame.ewm(dif, span=9, adjust=False).mean()
            macd = ((dif - dea) * 2)

            dif = dif[dif.index == pd.to_datetime(self.date)]
            dea = dea[dea.index == pd.to_datetime(self.date)]
            dif = dif[dif.index == pd.to_datetime(self.date)]
            self.__UpdateFactorFile(factor_path + 'macd/dif_26_12_9.csv', dif)
            self.__UpdateFactorFile(factor_path + 'macd/dea_26_12_9.csv', dea)
            self.__UpdateFactorFile(factor_path + 'macd/macd_26_12_9.csv', macd)
        except Exception as e:
            raise e


if __name__ == '__main__':
    engine = FactorEngineTool('2024-12-31')
    engine.UpdateMaFactor()
    print("UpdateMaFactor")
    engine.UpdateBollFactor()
    print("UpdateBollFactor")
    engine.UpdateDMAFactor()
    print("UpdateDMAFactor")
    engine.UpdateAberrationFactor()
    print("UpdateAberrationFactor")
    engine.UpdateMACDFactor()
    print("UpdateMACDFactor")