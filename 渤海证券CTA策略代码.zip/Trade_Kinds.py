# -*- coding: utf-8 -*-
"""
Created on 2025/5/20 09:40
@author: Wang bo
"""

import pandas as pd
from matplotlib import pyplot as plt
import numpy as np
from tqdm import tqdm

from GetFactorFile import Factor
from Back_Test import BackTest

pd.set_option('display.max_seq_items', None)
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
pd.options.mode.chained_assignment = None  # 关闭链式赋值警告（全局）

file_path = '../Fundamental_Data/'
save_path = '../Result_Data/所有品种/'
factor_path = save_path + 'factor/'


#=====================================================================
#资产组合回撤
#=====================================================================

def best_strategy_yearly(StartDate, EndDate):
    KindList = pd.read_csv(file_path+'主力合约信息.csv', encoding='gbk')['kind'].unique().tolist()
    df = []
    for kind in tqdm(KindList, desc='每个品种每个策略的年收益率'):
        tmp = []
        for strategy in ['aberration', 'boll1', 'boll2', 'dma', 'ma', 'macd']:
            model = Factor(StartDate, EndDate, kind, strategy)
            Info = model.info()
            factor = model.factor()
            merge = pd.merge(Info, factor, on=['date'], how='left')
            merge['signalBL'] = 1
            merge['signal'] = merge[kind].shift(1)
            valueDF = BackTest(merge)
            valueDF['Year'] = valueDF['date'].dt.year
            Ret = (valueDF.groupby('Year')['value']
                   .apply(lambda x:(x.dropna().iloc[-1]-x.dropna().iloc[0])/1000000)
                   .reset_index())
            Ret = Ret.rename(columns={Ret.columns[-1]:kind})
            Ret['YearStrategy'] = strategy+Ret['Year'].astype(str)
            Ret = Ret.set_index('YearStrategy')
            tmp.append(pd.DataFrame(Ret[kind]))
            #print(f'{kind}_{strategy}回撤完成')
        tmp = pd.concat(tmp, axis=0)
        df.append(tmp)
    RetYearlyAll = pd.concat(df, axis=1)
    RetYearlyAll['Strategy'] = RetYearlyAll.index.str[:-4]

    BestStrategy = RetYearlyAll.copy(deep=True)
    BestStrategy = BestStrategy.groupby('Strategy').shift(1)
    BestStrategy['Year'] = BestStrategy.index.str[-4:]
    BestStrategy['Strategy'] = BestStrategy.index.str[:-4]
    BestStrategy = BestStrategy.melt(id_vars=['Year', 'Strategy'], value_vars=BestStrategy.columns[:-2],
                                     var_name='kind', value_name='RetYearly')
    BestStrategy = (BestStrategy.sort_values(['Year', 'kind', 'RetYearly'], ascending=[True, True, False]).
                    groupby(['Year', 'kind']).head(1).
                    dropna())
    BestStrategy.to_csv(save_path+'单品种去年最优策略.csv', encoding='gbk')
    pass


def select_kinds_by_position(Num):
    """
    :param Num: 选取的组合品种数量
    :return: 每1个月交易的品种以及对应的去年最好的策略，每3个月交易的品种以及对应的去年最好的策略
    """
    BestStrategy = pd.read_csv(save_path+'单品种去年最优策略.csv', encoding='gbk')
    positionDF = pd.read_csv(file_path+'持仓量'+'.csv', encoding='gbk', index_col=0, parse_dates=['date'])
    DropList = ['T', 'TC', 'IC', 'IH', 'IF', 'ZC', 'TF', 'TS', 'IM', 'TL', 'SC', 'LU', 'BC',
                'CS', 'FB', 'RS', 'PM', 'WH', 'RI', 'JR', 'LR', 'BB', 'CJ', 'WR', 'RR']
    positionDF = positionDF.drop(columns=DropList)
    positionDF['YearMonth'] = positionDF.index.strftime('%Y%m')
    positionDF = positionDF.groupby('YearMonth').sum()
    positionDF = positionDF*3/(positionDF.shift(1) + positionDF.shift(2) + positionDF.shift(3))
    positionDF = positionDF.shift(1)
    positionDF[np.isinf(positionDF)] = np.nan

    conflict_dict = {
        "NI":"SS",
        "SS":"NI",
        "J":"JM",
        "JM":"J",
        "RB":"HC",
        "HC":"RB"
    }
    TradeList = []
    for month in positionDF.index:
        selected = []
        VolumeRatio = []
        row = positionDF.loc[month].dropna().sort_values(ascending=False)
        for kind, value in row.items():
            if kind in conflict_dict and conflict_dict[kind] in selected:
                continue
            selected.append(kind)
            VolumeRatio.append(value)

            if len(selected)==Num:
                break
        TradeList.append(pd.DataFrame({'YearMonth':month, 'kind':selected, 'Volume':VolumeRatio}))
        if len(selected)==0:
            TradeList.append(pd.DataFrame({'YearMonth':month, 'kind':[np.nan], 'Volume':[np.nan]}))
    Tra_kinds_1m = pd.concat(TradeList, axis=0)
    Tra_kinds_1m['Year'] = Tra_kinds_1m['YearMonth'].str[:4]
    Tra_kinds_1m = pd.merge(Tra_kinds_1m, BestStrategy, on=['Year', 'kind'], how='left')
    Tra_kinds_1m['Strategy'] = Tra_kinds_1m['Strategy'].fillna('ma')
    Tra_kinds_1m = pd.pivot(Tra_kinds_1m, index='YearMonth', columns='kind', values='Strategy')
    Tra_kinds_1m = Tra_kinds_1m.loc[:, Tra_kinds_1m.columns.notna()]
    Tra_kinds_1m = Tra_kinds_1m[Tra_kinds_1m.index.str[:4]!=Tra_kinds_1m.index[0][:4]]

    Tra_kinds_3m = []
    for i in range(0,3):
        InitDate = (pd.to_datetime(Tra_kinds_1m.index[0], format='%Y%m') + pd.DateOffset(months=i)).replace(day=1)
        tmp = Tra_kinds_1m[pd.to_datetime(Tra_kinds_1m.index, format='%Y%m') >= InitDate]
        for j in range(0, len(tmp), 3):
            if j+2<len(tmp):
                tmp.iloc[j+1:j+3] = tmp.iloc[j].values
        Tra_kinds_3m.append(tmp)
    return Tra_kinds_1m, Tra_kinds_3m


def select_kinds_by_volume(Num):
    """
    :param Num: 选取的组合品种数量
    :return: 每1个月交易的品种，每3个月交易的品种
    """
    BestStrategy = pd.read_csv(save_path+'单品种去年最优策略.csv', encoding='gbk')
    volumeDF = pd.read_csv(file_path+'交易量'+'.csv', encoding='gbk', index_col=0, parse_dates=['date'])
    DropList = ['T', 'TC', 'IC', 'IH', 'IF', 'ZC', 'TF', 'TS', 'IM', 'TL', 'SC', 'LU', 'BC',
                'CS', 'FB', 'RS', 'PM', 'WH', 'RI', 'JR', 'LR', 'BB', 'CJ', 'WR', 'RR']
    volumeDF = volumeDF.drop(columns=DropList)
    volumeDF['YearMonth'] = volumeDF.index.strftime('%Y%m')
    volumeDF = volumeDF.groupby('YearMonth').sum()
    volumeDF = volumeDF*3/(volumeDF.shift(1) + volumeDF.shift(2) + volumeDF.shift(3))
    volumeDF = volumeDF.shift(1)
    volumeDF[np.isinf(volumeDF)] = np.nan

    conflict_dict = {
        "NI":"SS",
        "SS":"NI",
        "J":"JM",
        "JM":"J",
        "RB":"HC",
        "HC":"RB"
    }
    TradeList = []
    for month in volumeDF.index:
        selected = []
        VolumeRatio = []
        row = volumeDF.loc[month].dropna().sort_values(ascending=False)
        for kind, value in row.items():
            if kind in conflict_dict and conflict_dict[kind] in selected:
                continue
            selected.append(kind)
            VolumeRatio.append(value)

            if len(selected)==Num:
                break
        TradeList.append(pd.DataFrame({'YearMonth':month, 'kind':selected, 'Volume':VolumeRatio}))
        if len(selected)==0:
            TradeList.append(pd.DataFrame({'YearMonth':month, 'kind':[np.nan], 'Volume':[np.nan]}))
    Tra_kinds_1m = pd.concat(TradeList, axis=0)
    Tra_kinds_1m['Year'] = Tra_kinds_1m['YearMonth'].str[:4].astype(int)
    Tra_kinds_1m = pd.merge(Tra_kinds_1m, BestStrategy, on=['Year', 'kind'], how='left')
    Tra_kinds_1m['Strategy'] = Tra_kinds_1m['Strategy'].fillna('ma')
    Tra_kinds_1m = pd.pivot(Tra_kinds_1m, index='YearMonth', columns='kind', values='Strategy')
    Tra_kinds_1m = Tra_kinds_1m.loc[:, Tra_kinds_1m.columns.notna()]
    Tra_kinds_1m = Tra_kinds_1m[Tra_kinds_1m.index.str[:4]!=Tra_kinds_1m.index[0][:4]]

    Tra_kinds_3m = []
    for i in range(0,3):
        InitDate = (pd.to_datetime(Tra_kinds_1m.index[0], format='%Y%m') + pd.DateOffset(months=i)).replace(day=1)
        tmp = Tra_kinds_1m[pd.to_datetime(Tra_kinds_1m.index, format='%Y%m') >= InitDate]
        for j in range(0, len(tmp), 3):
            if j+2<len(tmp):
                tmp.iloc[j+1:j+3] = tmp.iloc[j].values
        Tra_kinds_3m.append(tmp)
    return Tra_kinds_1m, Tra_kinds_3m


def select_kinds_by_cross(Num):
    BestStrategy = pd.read_csv(save_path+'单品种去年最优策略.csv', encoding='gbk')
    DropList = ['T', 'TC', 'IC', 'IH', 'IF', 'ZC', 'TF', 'TS', 'IM', 'TL', 'SC', 'LU', 'BC',
                'CS', 'FB', 'RS', 'PM', 'WH', 'RI', 'JR', 'LR', 'BB', 'CJ', 'WR', 'RR']

    holding = pd.read_csv(file_path+'持仓量.csv', encoding='gbk', index_col=0, parse_dates=['date'])
    holding = holding.drop(columns=DropList)
    holding['YearMonth'] = holding.index.strftime('%Y%m')
    holding = holding.groupby('YearMonth').sum()
    holding = holding*3/(holding.shift(1)+holding.shift(2)+holding.shift(3))
    holding = holding.shift(1)
    holding[np.isinf(holding)] = np.nan

    volume = pd.read_csv(file_path+'交易量.csv', encoding='gbk', index_col=0, parse_dates=['date'])
    volume = volume.drop(columns=DropList)
    volume['YearMonth'] = volume.index.strftime('%Y%m')
    volume = volume.groupby('YearMonth').sum()
    volume = volume*3/(volume.shift(1)+volume.shift(2)+volume.shift(3))
    volume = volume.shift(1)
    volume[np.isinf(volume)] = np.nan

    conflict_dict = {
        "NI":"SS",
        "SS":"NI",
        "J":"JM",
        "JM":"J",
        "RB":"HC",
        "HC":"RB"
    }
    TradeList1 = []
    for month in holding.index:
        selected = []
        HoldingRatio = []
        row = holding.loc[month].dropna().sort_values(ascending=False)
        for kind, value in row.items():
            if kind in conflict_dict and conflict_dict[kind] in selected:
                continue
            selected.append(kind)
            HoldingRatio.append(value)

            if len(selected)==Num:
                break
        TradeList1.append(pd.DataFrame({'YearMonth':month, 'kind':selected, 'holding':HoldingRatio}))
    TradeList1 = pd.concat(TradeList1, axis=0)
    TradeList1 = pd.pivot(TradeList1, index='YearMonth', columns='kind', values='holding')
    TradeList1.to_csv(save_path+'test_TradeList1.csv', encoding='gbk')

    TradeList2 = []
    for month in volume.index:
        selected = []
        VolumeRatio = []
        row = volume.loc[month].dropna().sort_values(ascending=False)
        for kind, value in row.items():
            if kind in conflict_dict and conflict_dict[kind] in selected:
                continue
            selected.append(kind)
            VolumeRatio.append(value)

            if len(selected)==Num:
                break
        TradeList2.append(pd.DataFrame({'YearMonth':month, 'kind':selected, 'volume':VolumeRatio}))
    TradeList2 = pd.concat(TradeList2, axis=0)
    TradeList2 = pd.pivot(TradeList2, index='YearMonth', columns='kind', values='volume')
    TradeList2.to_csv(save_path+'test_TradeList2.csv', encoding='gbk')

    tra_kinds_1m = pd.DataFrame()
    for index, row in TradeList1.iterrows():
        row1 = row.dropna().index
        row2 = TradeList2.loc[index].dropna().index
        common = row1.intersection(row2).tolist()
        tmp = pd.DataFrame({'YearMonth':index, 'kind':common})
        if len(common)==0:
            tmp = pd.DataFrame({'YearMonth':index, 'kind':[np.nan]})
        tra_kinds_1m = pd.concat([tra_kinds_1m, tmp], axis=0)
    tra_kinds_1m['Year'] = tra_kinds_1m['YearMonth'].str[:4]
    tra_kinds_1m = pd.merge(tra_kinds_1m, BestStrategy, on=['Year', 'kind'], how='left')
    tra_kinds_1m['Strategy'] = tra_kinds_1m['Strategy'].fillna('ma')
    tra_kinds_1m = pd.pivot(tra_kinds_1m, index='YearMonth', columns='kind', values='Strategy')
    tra_kinds_1m = tra_kinds_1m[tra_kinds_1m.index.str[:4]!=tra_kinds_1m.index[0][:4]]
    tra_kinds_1m = tra_kinds_1m.drop(columns=[np.nan])


    Tra_kinds_3m = []
    for i in range(0, 3):
        InitDate = (pd.to_datetime(tra_kinds_1m.index[0], format='%Y%m')+pd.DateOffset(months=i)).replace(day=1)
        tmp = tra_kinds_1m[pd.to_datetime(tra_kinds_1m.index, format='%Y%m')>=InitDate]
        for j in range(0, len(tmp), 3):
            if j+2<len(tmp):
                tmp.iloc[j+1:j+3] = tmp.iloc[j].values
        Tra_kinds_3m.append(tmp)

    return tra_kinds_1m, Tra_kinds_3m

