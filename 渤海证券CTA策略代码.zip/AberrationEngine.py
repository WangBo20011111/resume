﻿import pandas as pd
import os
import numpy as np

file_path = '../Fundamental_Data/'
save_path = '../Result_Data/所有品种/'
factor_path = save_path + 'factor/'


class AberrationEngine:
    def __init__(self, date, total_fund):
        self.date = date
        self.total_fund = total_fund


    def __UpdateFile(self, path, tmp):
        if os.path.exists(path):
            target = pd.read_csv(path, encoding='gbk', parse_dates=['date'])
        else:
            target = pd.DataFrame()
            try:
                os.makedirs(os.path.dirname(path))
            except:
                pass
        target = pd.concat([target, tmp], axis=0)
        if 'kind' in target.columns:
            target = target.drop_duplicates(subset=['date', 'kind'], keep='last')
            target = target.sort_values(['date', 'kind'])
        else:
            target = target.drop_duplicates(subset=['date'], keep='last')
            target = target.sort_values(['date'])
        target.to_csv(path, encoding='gbk', index=False)


    def __HandleFactor(self):
        highDF = pd.read_csv(factor_path + 'aberration/high_20_2.csv', index_col=0,
                             encoding='gbk', parse_dates=['date'])
        lowDF = pd.read_csv(factor_path + 'aberration/low_20_2.csv', index_col=0,
                            encoding='gbk', parse_dates=['date'])
        midDF = pd.read_csv(factor_path + 'aberration/mid_20_2.csv', index_col=0,
                            encoding='gbk', parse_dates=['date'])
        closeDF = pd.read_csv(save_path + 'close_adj.csv', index_col=0,
                              encoding='gbk', parse_dates=['date'])
        df1 = closeDF - highDF
        df1 = df1.map(lambda x: 1 if x > 0 else 0)
        df2 = lowDF - closeDF
        df2 = df2.map(lambda x: -1 if x > 0 else 0)
        res = df1 + df2
        res = res.replace(0, np.nan)
        res = res.ffill()
        #res.reset_index().to_csv(factor_path + 'aberration/factor.csv', encoding='gbk', index=False)

        df3 = closeDF-midDF
        df3 = df3.map(lambda x: 1 if x >= 0 else -1)
        res = res + df3
        res.reset_index().to_csv(factor_path + 'aberration/factor_f.csv', encoding='gbk', index=False)
        return res


    def AberrationHolding(self):
        factorDF = self.__HandleFactor()
        '''
        weightDF = pd.read_csv(save_path + 'weight/weight.csv', index_col=0, encoding='gbk', parse_dates=['date'])
        futureDF = pd.read_csv(file_path + '主力合约信息.csv', encoding='gbk', index_col=0, parse_dates=['date'])

        shareholdingDF =[]
        for i in factorDF.columns:
            weight = weightDF[(weightDF.index == pd.to_datetime(self.date)) &
                              (weightDF['kind'] == i)]['weight_adj'].values[0]
            code = futureDF[(futureDF.index == pd.to_datetime(self.date)) &
                            (futureDF['kind'] == i)]['code'].values[0]
            factor = factorDF[factorDF.index == pd.to_datetime(self.date)][i].values[0]
            fund = self.total_fund*weight
            if factor>0:
                tmp = pd.DataFrame([[self.date, code, 1, fund, i]], columns=['date', 'code', 'flag', 'fund', 'kind'])
            elif factor < 0:
                tmp = pd.DataFrame([[self.date, code, -1, fund, i]], columns=['date', 'code', 'flag', 'fund', 'kind'])
            else:
                tmp = pd.DataFrame()
            shareholdingDF = pd.concat([shareholdingDF, tmp], axis=0)
        self.__UpdateFile(save_path + 'shareholding/shareholding.csv', shareholdingDF)
        '''



if __name__ == '__main__':
    date = input('请输入日期(YYYY-MM-DD): ')
    total_fund = int(input('请输入总资金: '))
    engine = AberrationEngine(date, total_fund)
    engine.AberrationHolding()
