# -*- coding: utf-8 -*-
"""
Created on 2025/3/10 14:25
@author: Wang bo
"""
from jqdatasdk import *
auth('11111100076', '230wKyYd')
from multiprocessing import Pool
import pandas as pd
from matplotlib import pyplot as plt
from pandas.tseries.offsets import MonthEnd
from GetFactorFile import Factor
from Back_Test import BackTest
import Portfolio_Performance as pp
from tqdm import tqdm
import Trade_Kinds as tk

pd.set_option('display.max_seq_items', None)
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
pd.options.mode.chained_assignment = None  # 关闭链式赋值警告（全局）

file_path = '../Fundamental_Data/'
save_path = '../Result_Data/所有品种/'
factor_path = save_path + 'factor/'


#=====================================================================
#资产组合回撤
#=====================================================================


def backtest_ma(Paras):
    StrategyCol, which = Paras
    kind = StrategyCol.name
    TradeMonths = StrategyCol.dropna()
    Start = pd.to_datetime(StrategyCol.index[0]+'01', format='%Y%m%d')
    End = pd.to_datetime(StrategyCol.index[-1]+'01', format='%Y%m%d')
    End = pd.to_datetime(End+MonthEnd(0))
    Info = Factor(Start, End, kind).info()
    factor = Factor(Start, End, kind, 'ma').factor()
    try:
        df = pd.merge(Info, factor[['date', kind]], on=['date'], how='left')
        df['signal'] = df[kind].shift(1)
        if which != 'Benchmark':
            df.loc[~df['date'].dt.strftime('%Y%m').isin(TradeMonths.index), 'signal'] = 0
        else:
            df.loc[~df['signal'].isna(), 'signal'] = 1
            df.loc[~df['date'].dt.strftime('%Y%m').isin(TradeMonths.index), 'signal'] = 0
        value_df = BackTest(df)
    except:
        value_df = pd.DataFrame()
    return value_df


def backtest_best(Paras):
    StrategyCol, which = Paras
    kind = StrategyCol.name
    TradeMonths = StrategyCol.dropna()
    Start = pd.to_datetime(StrategyCol.index[0]+'01', format='%Y%m%d')
    End = pd.to_datetime(StrategyCol.index[-1]+'01', format='%Y%m%d')
    End = pd.to_datetime(End+MonthEnd(0))
    Info = Factor(Start, End, kind).info()

    try:
        factor = []
        for index, value in StrategyCol.dropna().items():
            Now = pd.to_datetime(index + '01', format='%Y%m%d')
            Start = Now - pd.DateOffset(months=1)
            End = pd.to_datetime(Now + MonthEnd(0))
            tmp = Factor(Start, End, kind, strategy=value).factor()
            factor.append(tmp)
        factor = pd.concat(factor, axis=0)
        factor = factor.drop_duplicates(subset=['date'], keep='first')
    except:
        factor = pd.DataFrame()

    try:
        df = pd.merge(Info, factor[['date', kind]], on=['date'], how='left')
        df['signal'] = df[kind].shift(1)
        if which != 'Benchmark':
            df.loc[~df['date'].dt.strftime('%Y%m').isin(TradeMonths.index), 'signal'] = 0
        else:
            df.loc[~df['signal'].isna(), 'signal'] = 1
            df.loc[~df['date'].dt.strftime('%Y%m').isin(TradeMonths.index), 'signal'] = 0
        value_df = BackTest(df)
    except:
        value_df = pd.DataFrame()
    return value_df



if __name__ == '__main__':
    StartDate = '2015-01-01'
    EndDate = '2024-12-31'
    method = '交易量'  #'持仓量', '交易量和持仓量'
    strategy = 'ma' #'best'

    best_strategy_yearly = tk.best_strategy_yearly(StartDate, EndDate)

    if method == '交易量':
        tra_kinds_1m, tra_kinds_3m = tk.select_kinds_by_volume(5)
    elif method == '持仓量':
        tra_kinds_1m, tra_kinds_3m = tk.select_kinds_by_position(5)
    else:
        tra_kinds_1m, tra_kinds_3m = tk.select_kinds_by_cross(5)
    stack = pd.concat(tra_kinds_3m, axis=1)


    for TradeList in [x for x in tra_kinds_3m]+[stack, tra_kinds_1m]:
        Paras = []
        for j in range(TradeList.shape[1]):
            StrategyCol = TradeList.iloc[:, j]
            Paras.append([StrategyCol, 'Benchmark'])
        if strategy == 'ma':
            with Pool(5) as pool:
                results = list(tqdm(pool.imap(backtest_ma, Paras), total=len(Paras), desc="整体进度"))
        elif strategy == 'best':
            with Pool(5) as pool:
                results = list(tqdm(pool.imap(backtest_best, Paras), total=len(Paras), desc="整体进度"))
        results = pd.concat(results,axis=0)
        print('---------------Benchmark-----------------')
        retBL = pp.PortfolioPerformance(results, TradeList).setup()
        print('-----------------------------------------')

        Paras = []
        for j in range(TradeList.shape[1]):
            StrategyCol = TradeList.iloc[:, j]
            Paras.append([StrategyCol, 'Strategy'])
        print('Paras构建完成')
        if strategy=='ma':
            with Pool(5) as pool:
                results = list(tqdm(pool.imap(backtest_ma, Paras), total=len(Paras), desc="整体进度"))
        elif strategy=='best':
            with Pool(5) as pool:
                results = list(tqdm(pool.imap(backtest_best, Paras), total=len(Paras), desc="整体进度"))
        results = pd.concat(results, axis=0)
        print('---------------Strategy-----------------')
        retST = pp.PortfolioPerformance(results, TradeList).setup()
        print('-----------------------------------------')

        graph_df = pd.concat([retBL['ret'], retST['ret']], axis=1)
        graph_df.columns = ['Benchmark','Strategy']
        pp.graph(graph_df)




