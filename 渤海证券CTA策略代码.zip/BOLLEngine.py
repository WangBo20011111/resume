﻿import pandas as pd
import os
import numpy as np

file_path = '../Fundamental_Data/'
save_path = '../Result_Data/所有品种/'
factor_path = save_path + 'factor/'


class BOLLEngine:
    def __init__(self, date, total_fund):
        self.date = date
        self.total_fund = total_fund

    def __UpdateFile(self, path, tmp):
        if os.path.exists(path):
            target = pd.read_csv(path, encoding='gbk', parse_dates=['date'])
        else:
            target = pd.DataFrame()
            try:
                os.makedirs(os.path.dirname(path))
            except:
                pass
        target = pd.concat([target, tmp], axis=0)
        if 'kind' in target.columns:
            target = target.drop_duplicates(subset=['date','kind'], keep='last')
            target = target.sort_values(['date','kind'])
        else:
            target = target.drop_duplicates(subset=['date'], keep='last')
            target = target.sort_values(['date'])
        target.to_csv(path, encoding='gbk', index=False)


    def __HandleFactor1(self):
        highDF = pd.read_csv(factor_path + 'boll/high_20_1.5.csv', index_col=0,
                             encoding='gbk', parse_dates=['date'])
        lowDF = pd.read_csv(factor_path + 'boll/low_20_1.5.csv', index_col=0,
                            encoding='gbk', parse_dates=['date'])
        closeDF = pd.read_csv(save_path + 'close_adj.csv', index_col=0,
                              encoding='gbk', parse_dates=['date'])
        df1 = closeDF - highDF
        df1 = df1.map(lambda x: 1 if x > 0 else 0)
        df2 = lowDF - closeDF
        df2 = df2.map(lambda x: -1 if x> 0 else 0)
        res = df1 + df2
        res = res.replace(0, np.nan)
        res = res.ffill()
        res.reset_index().to_csv(factor_path + 'boll/factor1_5.csv', encoding='gbk', index=False)
        return res


    def __HandleFactor2(self):
        highDF = pd.read_csv(factor_path + 'boll/high_20_2.csv', index_col=0,
                              encoding='gbk', parse_dates=['date'])
        lowDF = pd.read_csv(factor_path + 'boll/low_20_2.csv', index_col=0,
                             encoding='gbk', parse_dates=['date'])
        closeDF = pd.read_csv(save_path + 'close_adj.csv', index_col=0,
                              encoding='gbk', parse_dates=['date'])
        df1 = closeDF - highDF
        df1 = df1.map(lambda x: 1 if x > 0 else 0)
        df2 = lowDF - closeDF
        df2 = df2.map(lambda x: -1 if x> 0 else 0)
        res = df1 + df2
        res = res.replace(0, np.nan)
        res = res.ffill()
        res.reset_index().to_csv(factor_path + 'boll/factor2_0.csv', encoding='gbk', index=False)
        return res


    def BOLLHolding1(self):
        code_list = ['AL']
        factorDF = self.__HandleFactor1()
        '''
        weightDF = pd.read_csv(save_path + '/weight/weight.csv', index_col=0, encoding='gbk', parse_dates=['date'])
        futureDF = pd.read_csv(file_path + '主力合约信息.csv', encoding='gbk', index_col=0, parse_dates=['date'])

        for i in code_list:
            weight = weightDF[(weightDF.index == pd.to_datetime(self.date)) &
                              (weightDF['kind'] == i)]['weight_adj'].values[0]
            code = futureDF[(futureDF.index == pd.to_datetime(self.date)) &
                            (futureDF['kind'] == i)]['code'].values[0]
            factor = factorDF[factorDF.index == pd.to_datetime(self.date)][i].values[0]
            fund = self.total_fund*weight
            if factor>0:
                tmp = pd.DataFrame([[self.date, code, 1, fund, i]], columns=['date', 'code', 'flag', 'fund', 'kind'])
            elif factor < 0:
                tmp = pd.DataFrame([[self.date, code, -1, fund, i]], columns=['date', 'code', 'flag', 'fund', 'kind'])
            else:
                tmp = pd.DataFrame()
            self.__UpdateFile(save_path + 'shareholding/shareholding.csv', tmp)
        '''

    def BOLLHolding2(self):
        code_list = ['HC', 'FG', 'M']
        factorDF = self.__HandleFactor2()
        '''
        weightDF = pd.read_csv(save_path + 'weight/weight.csv', index_col=0, encoding='gbk', parse_dates=['date'])
        futureDF = pd.read_csv(file_path + '主力合约信息.csv', encoding='gbk', index_col=0, parse_dates=['date'])

        for i in code_list:
            weight = weightDF[(weightDF.index == pd.to_datetime(self.date)) &
                              (weightDF['kind'] == i)]['weight_adj'].values[0]
            code = futureDF[(futureDF.index == pd.to_datetime(self.date)) &
                            (futureDF['kind'] == i)]['code'].values[0]
            factor = factorDF[factorDF.index == pd.to_datetime(self.date)][i].values[0]
            fund = self.total_fund*weight
            if factor>0:
                tmp = pd.DataFrame([[self.date, code, 1, fund, i]], columns=['date', 'code', 'flag', 'fund', 'kind'])
            elif factor < 0:
                tmp = pd.DataFrame([[self.date, code, -1, fund, i]], columns=['date', 'code', 'flag', 'fund', 'kind'])
            else:
                tmp=pd.DataFrame()
            self.__UpdateFile(save_path + 'shareholding/shareholding.csv', tmp)
        '''


if __name__ == '__main__':
    date = '2014-01-02'
    total_fund = 4500000
    engine = BOLLEngine(date, total_fund)
    #engine.BOLLHolding1()
    engine.BOLLHolding2()
