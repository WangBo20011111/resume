# -*- coding: utf-8 -*-
"""
Created on 2025/2/28 20:02
@author: Wang bo
"""

import pandas as pd
import os
import numpy as np

file_path = '../Fundamental_Data/'
save_path = '../Result_Data/所有品种/'

if not os.path.exists(save_path):
    os.makedirs(save_path)



class WeightEngine:
    def __init__(self, date, KindList):
        self.KindList = KindList
        self.date = date


    def __UpdateFile(self, path, df):
        if os.path.exists(path):
            target = pd.read_csv(path, encoding='gbk', index_col=0, parse_dates=['date'])
        else:
            target = pd.DataFrame()
            try:
                os.makedirs(os.path.dirname(path))
            except:
                pass
        target = pd.concat([target, df], axis=0)
        target = target.reset_index()
        if 'kind' in target.columns:
            target = target.drop_duplicates(subset=['date','kind'], keep='last')
            target = target.sort_values(['date','kind'])
        else:
            target = target.drop_duplicates(subset=['date'], keep='last')
            target = target.sort_values(['date'])
        target.to_csv(path, encoding='gbk', index=False)


    #每次只更新date这一天
    def UpdateWeight(self):
        #计算收益率、收益率标准差、收益率标准差的倒数
        close_df = pd.read_csv(save_path + 'close_adj.csv', encoding='gbk', index_col=0, parse_dates=['date'])
        close_df = close_df[self.KindList]
        close_df = close_df[close_df.index <= pd.to_datetime(self.date)]
        ret_df = close_df.pct_change(fill_method=None) + 1
        vix = ret_df.rolling(window=20).std()
        vixr = vix.map(lambda x: 1 / x if x != 0 else x)

        #每20天的标准差倒数改成20天中第1天的值
        vixr['num'] = range(0, vixr.shape[0])
        vixr.loc[(vixr['num']%19!=0)] = np.nan
        type_df = vixr['num']/vixr['num']
        vixr = vixr[self.KindList].ffill()

        vix = vix.reset_index()
        vixr = vixr.reset_index()
        close_df = close_df.reset_index()
        type_df = type_df.reset_index()
        vix_p = vix.melt(id_vars=['date'], var_name='kind', value_name='vix')
        vixr_p = vixr.melt(id_vars=['date'], var_name='kind', value_name='vixr')
        close_p = close_df.melt(id_vars=['date'], var_name='kind', value_name='close_adj')
        weight_p = pd.merge(vix_p, vixr_p, on=['date','kind'], how='left')
        weight_p = pd.merge(weight_p, type_df, on=['date'], how='left')
        weight_p = pd.merge(weight_p, close_p, on=['date','kind'], how='left')

        #计算基本权重=标准差倒数/标准差倒数之和
        vixr_total = weight_p.groupby(['date'])['vixr'].sum().reset_index()
        vixr_total.columns = ['date', '波动率倒数和']
        weight_p = pd.merge(weight_p, vixr_total, how='left', on=['date']).set_index('date')
        weight_p['weight'] = weight_p['vixr'] / weight_p['波动率倒数和']
        weight_p = weight_p[weight_p.index == pd.to_datetime(self.date)]

        #计算组合的加权相关系数=weight*cor*weight_T
        cor = ret_df[ret_df.index <= self.date].corr()
        weight = weight_p['weight']
        cor = np.mat(cor)
        weight = np.mat(weight)
        C = (weight * cor * weight.T).sum() ** 0.5
        if np.isnan(C):
            print('部分品种无数据')

        #计算实际风险和组合相关系数调整后的权重=weight*(日目标标准差/当天实际标准差)/组合的加权相关系数
        weight_p['weight_adj'] = weight_p['weight'] * (0.03/(250**0.5)/weight_p['vix']) / C
        if weight_p['weight_adj'].sum() > 2.5:
            weight_p['weight_adj'] = weight_p['weight_adj'] / weight_p['weight_adj'].sum() * 2.5

        self.__UpdateFile(save_path + 'weight/weight.csv', weight_p)
        pass


    #每次将date日期前的所有日期都更新一遍
    def UpdateWeightHis(self):
        closeDF = pd.read_csv(save_path + 'close_adj.csv', encoding='gbk', index_col=0, parse_dates=['date'])
        closeDF = closeDF[self.KindList]
        retDF = closeDF.pct_change() + 1

        vixDF = retDF.rolling(window=20).std()
        vixrDF = vixDF.applymap(lambda x:1 / x if x != 0 else x)
        vixrDF['type'] = range(0, vixrDF.shape[0])
        vixrDF.loc[vixrDF['type'] % 19 != 0] = np.nan
        typeDF = vixrDF['type']
        vixrDF = vixrDF[self.KindList].ffill()

        typeDF = typeDF.reset_index()
        vixDF = vixDF.reset_index()
        vixrDF = vixrDF.reset_index()
        closeDF = closeDF.reset_index()
        vixP = vixDF.melt(id_vars=['date'], var_name= 'kind', value_name='vix')
        vixrP = vixrDF.melt(id_vars=['date'], var_name= 'kind', value_name='vixr')
        closeP = closeDF.melt(id_vars=['date'], var_name= 'kind', value_name='close_adj')
        res = pd.merge(vixP, vixrP, how='left', on=['date','kind'])
        res = pd.merge(res, typeDF, how='left', on=['date'])
        res = pd.merge(res, closeP, how='left', on=['date', 'kind'])

        vixr_total = res.groupby(['date'])['vixr'].sum().reset_index()
        vixr_total.columns = ['date', '波动率倒数和']
        res = pd.merge(res, vixr_total, how='left', on=['date']).set_index(['date'])
        res['weight'] = res['vixr'] / res['波动率倒数和']
        self.__UpdateFile(save_path + 'weight/weight.csv', res)

        weightDF = pd.DataFrame()
        for index, row in retDF.iterrows():
            cor = retDF[retDF.index <= index].corr()
            weight = res[res.index == index]['weight']
            cor = np.mat(cor)
            weight = np.mat(weight)
            C = (weight * cor * weight.T).sum() ** 0.5

            weight_tmp = res[res.index == index]
            weight_tmp['weight_adj'] = weight_tmp['weight'] * (0.06/(250**0.5)/weight_tmp['vix']) / C
            if weight_tmp['weight_adj'].sum() > 2.5:
                weight_tmp['weight_adj'] = weight_tmp['weight_adj']/weight_tmp['weight_adj'].sum() * 2.5
            weightDF = weightDF.append(weight_tmp)

        self.__UpdateFile(save_path + 'weight/weight.csv', weightDF)


if __name__ == '__main__':
    date = input("请输入日期(YYYY-MM-DD)：")
    KindList_str = input("请输入期货组合列表，多个期货之间用逗号分隔：")
    KindList = [item.strip() for item in KindList_str.split(',')]
    engine = WeightEngine(date, KindList)
    engine.UpdateWeight()